param (
	[parameter(Mandatory=$True, Position=0)] [string] $Username
)
Import-Module ActiveDirectory
Enable-AdAccount $Username
$user = Get-AdUser $Username
if ($user.Enabled -eq $True) {return 0} else {return 1}